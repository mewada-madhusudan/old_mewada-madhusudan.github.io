"""
Application Tile Widget
================================================================================
Converted from PyQt6 to Kivy/KivyMD - Individual application tile component
"""

import os
import shutil
import threading
from datetime import datetime, timedelta
from kivy.metrics import dp
from kivy.clock import Clock
from kivy.properties import StringProperty, BooleanProperty, NumericProperty
from kivymd.uix.card import MDCard
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.dialog import MDDialog
from kivymd.uix.chip import MDChip
import pandas as pd
import numpy as np
from security_manager import LauncherSecurity
from static_config import *

class InstallThread(threading.Thread):
    """Installation thread for copying applications"""
    
    def __init__(self, source, destination, callback):
        super().__init__()
        self.source = source
        self.destination = destination
        self.callback = callback
        self.daemon = True
        
    def run(self):
        """Run installation process"""
        try:
            if not os.path.exists(self.source):
                raise FileNotFoundError(f"Source file not found: {self.source}")
                
            total_size = os.path.getsize(self.source)
            copied_size = 0
            
            with open(self.source, 'rb') as src, open(self.destination, 'wb') as dst:
                while True:
                    chunk = src.read(1024)
                    if not chunk:
                        break
                    dst.write(chunk)
                    copied_size += len(chunk)
                    progress = int((copied_size / total_size) * 100)
                    Clock.schedule_once(lambda dt, p=progress: self.callback('progress', p))
                    
            Clock.schedule_once(lambda dt: self.callback('finished'))
            
        except Exception as e:
            Clock.schedule_once(lambda dt: self.callback('error', str(e)))

class EnvironmentChip(MDChip):
    """Environment status chip"""
    
    def __init__(self, env_type, **kwargs):
        super().__init__(**kwargs)
        self.text = env_type[:4] if len(env_type) > 4 else env_type
        
        # Set colors based on environment
        if env_type == "PROD":
            self.md_bg_color = PROD_COLOR
        elif env_type == "UAT":
            self.md_bg_color = UAT_COLOR
        else:
            self.md_bg_color = BETA_COLOR
            
        self.text_color = 'white'
        self.size_hint = (None, None)
        self.size = (dp(60), dp(30))

class ApplicationTile(MDCard):
    """Application tile widget"""
    
    app_name = StringProperty("")
    app_description = StringProperty("")
    shared_drive_path = StringProperty("")
    environment = StringProperty("")
    release_date = StringProperty("")
    validity_period = NumericProperty(0)
    version_number = NumericProperty(1.0)
    registration_id = StringProperty("")
    
    installed = BooleanProperty(False)
    is_expired = BooleanProperty(False)
    update_available = BooleanProperty(False)
    is_flipped = BooleanProperty(False)
    
    def __init__(self, app_name, app_description, shared_drive_path, environment,
                 release_date, validity_period, version_number, registration_id, **kwargs):
        super().__init__(**kwargs)
        
        # Set properties
        self.app_name = app_name
        self.app_description = app_description
        self.shared_drive_path = shared_drive_path
        self.environment = environment
        self.release_date = release_date
        self.validity_period = validity_period
        self.version_number = version_number
        self.registration_id = registration_id
        
        # Set up paths
        self.install_path = os.path.join(os.environ.get('USERPROFILE'), APP_DIR, app_name)
        
        # Check status
        self.installed = self.is_app_installed(f"{self.install_path}.exe")
        self.is_expired = self.check_validity()
        self.update_available = self.check_update_available()
        
        # Card properties
        self.elevation = 3
        self.radius = [10]
        self.size_hint = (None, None)
        self.size = (dp(287), dp(200))
        self.md_bg_color = 'white'
        
        # Build UI
        self.build_ui()
        
        # Add expired overlay if needed
        if self.is_expired:
            self.add_expired_overlay()
            
    def build_ui(self):
        """Build the tile UI"""
        main_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(15)
        )
        
        # Header with name and environment
        header_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(40),
            adaptive_height=True
        )
        
        # App name
        self.name_label = MDLabel(
            text=self.app_name,
            font_style='H6',
            theme_text_color='Primary',
            size_hint_x=0.7
        )
        
        # Environment chip
        self.env_chip = EnvironmentChip(self.environment)
        
        header_layout.add_widget(self.name_label)
        header_layout.add_widget(self.env_chip)
        
        # Description
        self.description_label = MDLabel(
            text=self.app_description.strip(),
            font_style='Body2',
            theme_text_color='Secondary',
            text_size=(dp(250), None),
            size_hint_y=None,
            height=dp(80)
        )
        
        # Buttons
        button_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(40),
            adaptive_height=True
        )
        
        self.install_launch_button = MDRaisedButton(
            text="Install",
            md_bg_color='#00477b',
            size_hint_x=0.6
        )
        self.install_launch_button.bind(on_release=self.on_install_launch_clicked)
        
        self.uninstall_button = MDFlatButton(
            text="Uninstall",
            theme_text_color='Custom',
            text_color='#c5c9d0',
            size_hint_x=0.4
        )
        self.uninstall_button.bind(on_release=self.on_uninstall_clicked)
        
        button_layout.add_widget(self.install_launch_button)
        button_layout.add_widget(self.uninstall_button)
        
        # Status label
        self.status_label = MDLabel(
            text="Not Installed",
            font_style='Caption',
            theme_text_color='Secondary',
            size_hint_y=None,
            height=dp(20)
        )
        
        # Progress bar
        self.progress_bar = MDProgressBar(
            value=0,
            size_hint_y=None,
            height=dp(4),
            opacity=0
        )
        
        # Add widgets to main layout
        main_layout.add_widget(header_layout)
        main_layout.add_widget(self.description_label)
        main_layout.add_widget(button_layout)
        main_layout.add_widget(self.status_label)
        main_layout.add_widget(self.progress_bar)
        
        self.add_widget(main_layout)
        
        # Update button states
        self.update_button_states()
        
    def on_install_launch_clicked(self, *args):
        """Handle install/launch button click"""
        if self.update_available:
            self.update_application()
        elif not self.installed:
            self.install_application()
        else:
            self.launch_application()
            
    def install_application(self):
        """Install the application"""
        pslv_action_entry([{'SID': user_main, 'action': f'Installing {self.app_name}'}])
        
        self.progress_bar.opacity = 1
        self.status_label.text = "Installing..."
        
        # Create installation directory
        os.makedirs(self.install_path, exist_ok=True)
        
        # Get destination file path
        destination_file = os.path.join(self.install_path, f"{self.app_name}.exe")
        
        # Start installation thread
        self.install_thread = InstallThread(
            self.shared_drive_path,
            destination_file,
            self.on_install_callback
        )
        self.install_thread.start()
        
    def on_install_callback(self, event_type, *args):
        """Handle installation callbacks"""
        if event_type == 'progress':
            progress = args[0]
            self.progress_bar.value = progress
        elif event_type == 'finished':
            self.installation_finished()
        elif event_type == 'error':
            error_message = args[0]
            self.installation_error(error_message)
            
    def installation_finished(self):
        """Handle installation completion"""
        self.installed = True
        self.save_installed_version()
        self.update_available = False
        self.update_button_states()
        self.progress_bar.opacity = 0
        
        # Show success dialog
        dialog = MDDialog(
            title="Installation Complete",
            text=f"{self.app_name} has been successfully installed.",
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
        
    def installation_error(self, error_message):
        """Handle installation error"""
        self.progress_bar.opacity = 0
        self.status_label.text = "Installation Failed"
        
        dialog = MDDialog(
            title="Installation Error",
            text=f"Failed to install {self.app_name}: {error_message}",
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
        
    def launch_application(self):
        """Launch the application"""
        pslv_action_entry([{'SID': user_main, 'action': f'Launched {self.app_name}'}])
        
        executable_path = os.path.join(self.install_path, f"{self.app_name}.exe")
        
        if os.path.exists(executable_path):
            try:
                if self.registration_id is np.nan and self.environment == 'BETA':
                    release_date = pd.Timestamp(self.release_date)
                    expiry_date = release_date + timedelta(days=self.validity_period)
                    days_remaining = expiry_date - datetime.now()
                    
                    dialog = MDDialog(
                        title="Action Required",
                        text=f'Application is not registered at IA Hub and will stop working in {days_remaining.days} days.',
                        buttons=[
                            MDFlatButton(
                                text="OK",
                                on_release=lambda x: dialog.dismiss()
                            )
                        ]
                    )
                    dialog.open()
                    
                # Generate launch token and start application
                LauncherSecurity.generate_launch_token(executable_path)
                os.startfile(executable_path)
                
            except Exception as e:
                dialog = MDDialog(
                    title="Error",
                    text=f'Failed to launch application: {str(e)}',
                    buttons=[
                        MDFlatButton(
                            text="OK",
                            on_release=lambda x: dialog.dismiss()
                        )
                    ]
                )
                dialog.open()
        else:
            dialog = MDDialog(
                title="Error",
                text=f'Application executable not found at {executable_path}',
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: dialog.dismiss()
                    )
                ]
            )
            dialog.open()
            
    def on_uninstall_clicked(self, *args):
        """Handle uninstall button click"""
        if self.installed:
            try:
                shutil.rmtree(self.install_path)
                self.installed = False
                self.status_label.text = "Not Installed"
                self.install_launch_button.text = "Install"
                
                pslv_action_entry([{'SID': user_main, 'action': f'Uninstalled {self.app_name}'}])
                
                dialog = MDDialog(
                    title="Uninstall Complete",
                    text=f'{self.app_name} has been successfully uninstalled.',
                    buttons=[
                        MDFlatButton(
                            text="OK",
                            on_release=lambda x: dialog.dismiss()
                        )
                    ]
                )
                dialog.open()
                
            except Exception as e:
                dialog = MDDialog(
                    title="Uninstall Error",
                    text=f'Failed to uninstall {self.app_name}: {str(e)}',
                    buttons=[
                        MDFlatButton(
                            text="OK",
                            on_release=lambda x: dialog.dismiss()
                        )
                    ]
                )
                dialog.open()
                
    def is_app_installed(self, local_path):
        """Check if app is installed"""
        return os.path.exists(local_path)
        
    def check_validity(self):
        """Check if application has expired"""
        try:
            release_date = pd.Timestamp(self.release_date)
            expiry_date = release_date + timedelta(days=self.validity_period)
            return datetime.now() > expiry_date
        except Exception as e:
            print(f"Error checking validity: {str(e)}")
            return False
            
    def check_update_available(self):
        """Check if update is available"""
        try:
            installed_version = self.get_installed_version()
            if self.version_number and self.installed:
                if installed_version is None:
                    return True
                return float(self.version_number) > float(installed_version)
            return False
        except Exception as e:
            print(f"Error checking for updates: {str(e)}")
            return False
            
    def get_installed_version(self):
        """Get installed version from file"""
        version_file = os.path.join(self.install_path, "version.txt")
        if os.path.exists(version_file):
            try:
                with open(version_file, 'r') as f:
                    return float(f.read().strip())
            except:
                return None
        return None
        
    def save_installed_version(self):
        """Save current version to file"""
        try:
            os.makedirs(self.install_path, exist_ok=True)
            version_file = os.path.join(self.install_path, "version.txt")
            with open(version_file, 'w') as f:
                f.write(str(self.version_number))
        except Exception as e:
            print(f"Error saving version info: {str(e)}")
            
    def update_application(self):
        """Update the application"""
        if os.path.exists(self.install_path):
            shutil.rmtree(self.install_path)
        self.install_application()
        
    def update_button_states(self):
        """Update button states based on status"""
        if self.is_expired:
            self.status_label.text = "Application Expired" if self.environment == "PROD" else "UAT Period Expired"
            self.install_launch_button.disabled = True
            self.uninstall_button.disabled = True
            return
            
        if self.update_available:
            self.install_launch_button.text = "Update"
            self.status_label.text = "Update Available"
        elif self.installed:
            self.install_launch_button.text = "Launch"
            self.status_label.text = "Ready for Launch"
        else:
            self.install_launch_button.text = "Install"
            self.status_label.text = "Not Installed"
            
    def add_expired_overlay(self):
        """Add expired overlay to tile"""
        # Disable the tile and change appearance
        self.md_bg_color = '#f5f5f5'
        self.disabled = True
        
        # Update text colors to gray
        self.name_label.theme_text_color = 'Hint'
        self.description_label.theme_text_color = 'Disabled'