"""
PSLV Kivy/KivyMD Application - Main Entry Point
================================================================================
Converted from PyQt6 to Kivy/KivyMD framework
"""

import os
import sys
from kivy.app import App
from kivy.config import Config
from kivy.core.window import Window
from kivymd.app import MDApp
from kivymd.theming import ThemableBehavior
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager

# Configure Kivy before importing other modules
Config.set('graphics', 'width', '1200')
Config.set('graphics', 'height', '720')
Config.set('graphics', 'minimum_width', '800')
Config.set('graphics', 'minimum_height', '600')

from splash_screen import SplashScreen
from main_window import MainWindow
from static_config import *

class PSLVApp(MDApp):
    """Main PSLV Application class"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "PSLV by STO, GF&BM India"
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"
        self.theme_cls.material_style = "M3"
        
        # Application data
        self.processed_data = None
        self.cost_centers = None
        self.user_data = None
        
    def build(self):
        """Build the application"""
        # Set window properties
        Window.size = (1200, 720)
        Window.minimum_width = 800
        Window.minimum_height = 600
        
        # Create screen manager
        self.screen_manager = MDScreenManager()
        
        # Create and add splash screen
        self.splash_screen = SplashScreen(name='splash')
        self.splash_screen.bind(on_data_loaded=self.on_data_loaded)
        self.screen_manager.add_widget(self.splash_screen)
        
        return self.screen_manager
    
    def on_data_loaded(self, instance, data, cost_centers, user_data):
        """Handle data loaded from splash screen"""
        self.processed_data = data
        self.cost_centers = cost_centers
        self.user_data = user_data
        
        # Create and switch to main window
        main_window = MainWindow(
            name='main',
            df=data,
            cost_center=cost_centers,
            userdata=user_data
        )
        self.screen_manager.add_widget(main_window)
        self.screen_manager.current = 'main'
    
    def on_start(self):
        """Called when the app starts"""
        pass
    
    def on_stop(self):
        """Called when the app stops"""
        pass

if __name__ == '__main__':
    PSLVApp().run()