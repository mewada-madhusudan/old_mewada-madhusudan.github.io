"""
Splash Screen for PSLV Application
================================================================================
Converted from PyQt6 to Kivy/KivyMD - Loading screen with progress bar
"""

import os
import getpass
import threading
import time
from kivy.event import EventDispatcher
from kivy.clock import Clock
from kivy.properties import StringProperty, NumericProperty
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.card import MDCard
from kivy.uix.widget import Widget
from kivy.metrics import dp
import pandas as pd
import urllib3
from requests_ntlm import HttpNtlmAuth
from shareplum import Site
from static_config import *

# Suppress ssl warnings for sharepoint api calls
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DataLoader(threading.Thread, EventDispatcher):
    """Data loader thread for SharePoint data"""
    
    def __init__(self, callback, **kwargs):
        threading.Thread.__init__(self)
        EventDispatcher.__init__(self)
        self.callback = callback
        self.should_stop = False
        self.daemon = True
        
    def stop(self):
        """Stop the data loading process"""
        self.should_stop = True
        
    def run(self):
        """Load data from SharePoint"""
        try:
            if self.should_stop:
                return
                
            # Create backup directory
            os.makedirs(name=f"{os.environ.get('LOCALAPPDATA')}/{BACKUP_PATH}", exist_ok=True)
            
            user = getpass.getuser().lower()
            
            # SharePoint client initialization
            Clock.schedule_once(lambda dt: self.callback('progress', 5, "Initializing connection..."))
            if self.should_stop:
                return
                
            cred = HttpNtlmAuth(SID, password='')
            
            Clock.schedule_once(lambda dt: self.callback('progress', 15, "Connecting to SharePoint..."))
            if self.should_stop:
                return
                
            # Add timeout to prevent hanging
            try:
                site = Site(SITE_URL, auth=cred, verify_ssl=False, timeout=30)
            except Exception as e:
                raise ConnectionError(f"Failed to connect to SharePoint: {str(e)}")
                
            Clock.schedule_once(lambda dt: self.callback('progress', 35, "Fetching application data..."))
            if self.should_stop:
                return
                
            # Fetch data from SharePoint list with timeout
            sp_list = site.List(SHAREPOINT_LIST)
            sp_data = sp_list.GetListItems(view_name=None)
            
            if self.should_stop:
                return
                
            df_all = pd.DataFrame(sp_data)
            df_all.fillna(value='', inplace=True)
            df_all['SIDs_For_SolutionAccess'] = df_all['SIDs_For_SolutionAccess'].str.lower()
            df_all.fillna(value='', inplace=True)
            
            Clock.schedule_once(lambda dt: self.callback('progress', 50, "Processing user access..."))
            if self.should_stop:
                return
                
            all_df = df_all[df_all['SIDs_For_SolutionAccess'].str.contains('everyone', na=False)]
            processed_df = df_all[df_all['SIDs_For_SolutionAccess'].str.contains(user, na=False)]
            processed_df = pd.concat([all_df, processed_df])
            
            Clock.schedule_once(lambda dt: self.callback('progress', 70, "Saving local backup..."))
            if self.should_stop:
                return
                
            processed_df.reset_index(inplace=True)
            backup_path = f"{os.environ.get('LOCALAPPDATA')}/{BACKUP_PATH}/{BACKUP_FILE_NAME}"
            processed_df.to_excel(excel_writer=backup_path, index=False)
            
            Clock.schedule_once(lambda dt: self.callback('progress', 85, "Loading additional data..."))
            if self.should_stop:
                return
                
            # Load additional data with error handling
            try:
                cc = self.fetch_cost_centers(site)
                user_data = self.fetch_user_data(site)
            except Exception as e:
                print(f"Warning: Failed to load additional data: {str(e)}")
                cc = pd.DataFrame()
                user_data = pd.DataFrame()
                
            if self.should_stop:
                return
                
            Clock.schedule_once(lambda dt: self.callback('progress', 100, "Loading complete!"))
            # Emit the processed data
            Clock.schedule_once(lambda dt: self.callback('data_loaded', processed_df, cc, user_data))
            
        except ConnectionError as e:
            error_msg = f'Connection error: {str(e)}'
            print(error_msg)
            Clock.schedule_once(lambda dt: self.callback('error', "Failed to connect to SharePoint. Loading from backup..."))
            self._load_from_backup()
            
        except Exception as e:
            error_msg = f'Error loading data: {str(e)}'
            print(error_msg)
            Clock.schedule_once(lambda dt: self.callback('error', "Failed to load data from SharePoint. Loading from backup..."))
            self._load_from_backup()
            
    def fetch_cost_centers(self, site):
        """Fetch cost centers from SharePoint list"""
        try:
            sp_list = site.List(COST_CENTER)
            sp_data = sp_list.GetListItems(view_name=None)
            df = pd.DataFrame(sp_data)
            df.fillna(value='', inplace=True)
            return df
        except Exception as e:
            print(f'Error fetching cost centers: {str(e)}')
            return pd.DataFrame(columns=['cost_center_code', 'cost_center_name', 'is_gfbm'])
            
    def fetch_user_data(self, site):
        """Fetch user data from SharePoint list"""
        try:
            sp_list = site.List(USERBASE)
            query = {'Where': [('Contains', 'sid', user_main)]}
            
            # Fetch items with the query and row limit
            sp_data = sp_list.GetListItems(query=query)
            df = pd.DataFrame(sp_data)
            df.fillna(value='', inplace=True)
            return df
        except Exception as e:
            print(f'Error fetching user data: {str(e)}')
            return pd.DataFrame(columns=['sid', 'display_name', 'email', 'job_title', 'building_name', 'cost_center_id'])
            
    def _load_from_backup(self):
        """Load data from backup file"""
        try:
            backup_path = f"{os.environ.get('LOCALAPPDATA')}/{BACKUP_PATH}/{BACKUP_FILE_NAME}"
            if os.path.exists(backup_path):
                processed_df = pd.read_excel(backup_path)
                Clock.schedule_once(lambda dt: self.callback('progress', 100, "Loaded from backup"))
                Clock.schedule_once(lambda dt: self.callback('data_loaded', processed_df, pd.DataFrame(), pd.DataFrame()))
            else:
                processed_df = pd.DataFrame(
                    columns=['Expired', 'Solution_Name', 'Description', 'ApplicationExePath', 'Status', 'Release_Date',
                             'Validity_Period', 'Version_Number', 'UMAT_IAHub_ID'])
                Clock.schedule_once(lambda dt: self.callback('error', "No backup data available. Please check your connection."))
                Clock.schedule_once(lambda dt: self.callback('data_loaded', processed_df, pd.DataFrame(), pd.DataFrame()))
        except Exception as e:
            print(f"Error loading backup: {str(e)}")
            processed_df = pd.DataFrame(
                columns=['Expired', 'Solution_Name', 'Description', 'ApplicationExePath', 'Status', 'Release_Date',
                         'Validity_Period', 'Version_Number', 'UMAT_IAHub_ID'])
            Clock.schedule_once(lambda dt: self.callback('data_loaded', processed_df, pd.DataFrame(), pd.DataFrame()))

class SplashScreen(MDScreen):
    """Splash screen with loading progress"""
    
    progress_value = NumericProperty(0)
    status_text = StringProperty("Initializing...")
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.data_loader = None
        self.can_cancel = False
        
        # Register custom event
        self.register_event_type('on_data_loaded')
        
        # Build UI
        self.build_ui()
        
        # Start data loading after a short delay
        Clock.schedule_once(self.start_loading, 0.1)
        
    def build_ui(self):
        """Build the splash screen UI"""
        # Main container
        main_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(20),
            adaptive_height=True,
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            size_hint=(0.8, None)
        )
        
        # Create card container
        card = MDCard(
            md_bg_color='#2F4454',
            elevation=10,
            radius=[15],
            size_hint=(None, None),
            size=(dp(600), dp(400)),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Card content
        card_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(20),
            adaptive_height=True,
            padding=dp(40)
        )
        
        # Title
        title_label = MDLabel(
            text='Python Solution Launcher for VDI',
            theme_text_color='Custom',
            text_color='#93deed',
            font_style='H4',
            halign='center',
            size_hint_y=None,
            height=dp(60)
        )
        
        # Description
        desc_label = MDLabel(
            text=LABEL_TEXT,
            theme_text_color='Custom',
            text_color='#c2ced1',
            font_style='Body1',
            halign='center',
            size_hint_y=None,
            height=dp(30)
        )
        
        # Progress bar
        self.progress_bar = MDProgressBar(
            value=0,
            size_hint=(1, None),
            height=dp(10),
            color='#376E6F'
        )
        
        # Status label
        self.status_label = MDLabel(
            text=self.status_text,
            theme_text_color='Custom',
            text_color='#e8e8eb',
            font_style='Body2',
            halign='center',
            size_hint_y=None,
            height=dp(30)
        )
        
        # Cancel button (initially hidden)
        self.cancel_button = MDRaisedButton(
            text="Cancel",
            md_bg_color='#f44336',
            size_hint=(None, None),
            size=(dp(100), dp(36)),
            pos_hint={'center_x': 0.5},
            opacity=0
        )
        self.cancel_button.bind(on_release=self.cancel_loading)
        
        # Add widgets to card
        card_layout.add_widget(title_label)
        card_layout.add_widget(desc_label)
        card_layout.add_widget(Widget(size_hint_y=None, height=dp(20)))
        card_layout.add_widget(self.progress_bar)
        card_layout.add_widget(self.status_label)
        card_layout.add_widget(Widget(size_hint_y=None, height=dp(10)))
        card_layout.add_widget(self.cancel_button)
        
        card.add_widget(card_layout)
        self.add_widget(card)
        
    def start_loading(self, dt):
        """Start the data loading process"""
        if self.data_loader:
            self.data_loader.stop()
            
        self.data_loader = DataLoader(self.on_loader_callback)
        self.data_loader.start()
        
    def on_loader_callback(self, event_type, *args):
        """Handle callbacks from data loader"""
        if event_type == 'progress':
            value, message = args
            self.update_progress(value, message)
        elif event_type == 'data_loaded':
            data, cost_centers, user_data = args
            self.on_data_loaded_internal(data, cost_centers, user_data)
        elif event_type == 'error':
            message = args[0]
            self.on_error(message)
            
    def update_progress(self, value, message="Loading..."):
        """Update progress bar and status"""
        self.progress_bar.value = value
        self.status_label.text = message
        
        # Show cancel button after initial connection attempt
        if value > 20 and not self.can_cancel:
            self.can_cancel = True
            self.cancel_button.opacity = 1
            
    def on_error(self, error_message):
        """Handle error messages"""
        self.status_label.text = error_message
        self.status_label.text_color = '#ff9800'  # Orange color for warnings
        
    def cancel_loading(self, *args):
        """Cancel the loading process"""
        if self.data_loader and self.data_loader.is_alive():
            self.data_loader.stop()
        self.manager.get_screen('splash').manager.current = 'main'
        
    def on_data_loaded_internal(self, data, cost_centers, user_data):
        """Handle data loaded completion"""
        self.progress_bar.value = 100
        self.dispatch('on_data_loaded', data, cost_centers, user_data)
        
    def on_data_loaded(self, data, cost_centers, user_data):
        """Event handler for data loaded - override in parent"""
        pass