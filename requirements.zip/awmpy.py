"""
Mock awmpy module - Replacement for the original awmpy dependency
================================================================================
This is a mock implementation to replace the missing awmpy dependency
"""

def get_phonebook_data(user_id):
    """Mock function to get phonebook data"""
    return {
        'standardID': user_id,
        'nameFull': f'User {user_id}',
        'email': f'{user_id}@company.com',
        'jobTitle': 'Associate',
        'buildingName': 'GF&BM, India',
        'costCenterID': '12345'
    }