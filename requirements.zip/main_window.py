"""
Main Window for PSLV Application
================================================================================
Converted from PyQt6 to Kivy/KivyMD - Main application interface
"""

import os
import getpass
from kivy.metrics import dp
from kivy.clock import Clock
from kivy.properties import StringProperty, ListProperty
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.button import MDRaisedButton, MDIconButton
from kivymd.uix.card import MDCard
from kivymd.uix.navigationdrawer import MDNavigationLayout, MDNavigationDrawer
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.list import MDList, OneLineListItem
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
import pandas as pd
import numpy as np
from application_tile import ApplicationTile
from access_control import AccessControlDialog
from static_config import *

user_main = getpass.getuser()

class NoAccessWidget(MDCard):
    """Widget shown when user has no access to applications"""
    
    def __init__(self, is_gfbm_user=True, **kwargs):
        super().__init__(**kwargs)
        self.md_bg_color = '#f8f9fa'
        self.radius = [10]
        self.elevation = 2
        self.size_hint = (0.8, None)
        self.height = dp(300)
        self.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        
        layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(20),
            adaptive_height=True,
            padding=dp(40)
        )
        
        # Icon (using emoji as fallback)
        icon_label = MDLabel(
            text="⚠",
            font_size='48sp',
            theme_text_color='Custom',
            text_color='#6c757d',
            halign='center',
            size_hint_y=None,
            height=dp(60)
        )
        
        # Title
        title_label = MDLabel(
            text="No Application Access",
            font_style='H5',
            theme_text_color='Custom',
            text_color='#343a40',
            halign='center',
            size_hint_y=None,
            height=dp(40)
        )
        
        # Description
        if is_gfbm_user:
            desc_text = ("Currently, you do not have access to any application.\n"
                        "Please contact administrator for access permissions.")
        else:
            desc_text = ("Thanks for showing your interest for PSLV.\n"
                        "At present, Application is accessible for Global Finance & Business Management India.")
        
        desc_label = MDLabel(
            text=desc_text,
            font_style='Body1',
            theme_text_color='Custom',
            text_color='#6c757d',
            halign='center',
            size_hint_y=None,
            height=dp(80)
        )
        
        # Help button
        help_button = MDRaisedButton(
            text="Help Center!!!",
            md_bg_color='#4a90e2',
            size_hint=(None, None),
            size=(dp(200), dp(40)),
            pos_hint={'center_x': 0.5}
        )
        help_button.bind(on_release=self.contact_admin)
        
        layout.add_widget(icon_label)
        layout.add_widget(title_label)
        layout.add_widget(desc_label)
        layout.add_widget(help_button)
        
        self.add_widget(layout)
        
    def contact_admin(self, *args):
        """Open help center link"""
        import webbrowser
        support_url = "https://confluence.prod.aws.jpmchase.net/confluence/spaces/GFITECH/pages/5228999093/APPLICATION+OWNER+AND+ADMINS"
        webbrowser.open(support_url)

class MainWindow(MDScreen):
    """Main application window"""
    
    def __init__(self, df, cost_center, userdata, **kwargs):
        super().__init__(**kwargs)
        self.all_tiles = []
        self.access = df
        self.cost_center_df = cost_center
        self.userdata = userdata
        self.user_details = self.get_user_details()
        self.is_gfbm_user = self.is_gfbm_user_check()
        self.username = user_main
        self.access_control_dialog = None
        
        self.build_ui()
        
    def build_ui(self):
        """Build the main UI"""
        # Navigation layout
        nav_layout = MDNavigationLayout()
        
        # Main content
        main_content = MDBoxLayout(orientation='vertical')
        
        # Top app bar
        toolbar = MDTopAppBar(
            title="PSLV by STO, GF&BM India",
            elevation=2,
            md_bg_color='#242526'
        )
        
        # Search and content area
        content_area = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(20)
        )
        
        # Search bar
        search_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(60),
            adaptive_height=True
        )
        
        self.search_field = MDTextField(
            hint_text="🔍 Search applications...",
            size_hint_x=0.8,
            mode="outlined"
        )
        self.search_field.bind(text=self.filter_applications)
        
        refresh_button = MDIconButton(
            icon="refresh",
            theme_icon_color="Custom",
            icon_color='#4a90e2'
        )
        refresh_button.bind(on_release=self.refresh_applications)
        
        search_layout.add_widget(self.search_field)
        search_layout.add_widget(refresh_button)
        
        # Scroll area for applications
        scroll_area = MDScrollView()
        
        # Application grid
        self.app_grid = MDGridLayout(
            cols=3,
            spacing=dp(20),
            adaptive_height=True,
            size_hint_y=None,
            padding=dp(10)
        )
        self.app_grid.bind(minimum_height=self.app_grid.setter('height'))
        
        scroll_area.add_widget(self.app_grid)
        
        # Add widgets to content area
        content_area.add_widget(search_layout)
        content_area.add_widget(scroll_area)
        
        # Add to main content
        main_content.add_widget(toolbar)
        main_content.add_widget(content_area)
        
        # Navigation drawer
        nav_drawer = self.create_navigation_drawer()
        
        # Add to navigation layout
        nav_layout.add_widget(main_content)
        nav_layout.add_widget(nav_drawer)
        
        self.add_widget(nav_layout)
        
        # Load applications or show no access
        if len(self.access) != 0 and self.is_gfbm_user:
            self.load_applications()
        else:
            self.show_no_access()
            
    def create_navigation_drawer(self):
        """Create the navigation drawer"""
        nav_drawer = MDNavigationDrawer(
            radius=(0, 16, 16, 0),
            md_bg_color='#242526'
        )
        
        drawer_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(20)
        )
        
        # Logo/Title
        title_label = MDLabel(
            text="PSLV",
            font_style='H4',
            theme_text_color='Custom',
            text_color='white',
            halign='center',
            size_hint_y=None,
            height=dp(60)
        )
        
        # User details
        for detail, icon in self.user_details:
            detail_item = OneLineListItem(
                text=str(detail),
                theme_text_color='Custom',
                text_color='white'
            )
            drawer_layout.add_widget(detail_item)
            
        # Access management button (for admins)
        if self.is_administrator():
            access_button = MDRaisedButton(
                text="Access Management",
                md_bg_color='#2670A9',
                size_hint_y=None,
                height=dp(40)
            )
            access_button.bind(on_release=self.show_access_control)
            drawer_layout.add_widget(access_button)
            
        # Exit button
        exit_button = MDRaisedButton(
            text="Exit",
            md_bg_color='#A6150B',
            size_hint_y=None,
            height=dp(40)
        )
        exit_button.bind(on_release=self.exit_app)
        drawer_layout.add_widget(exit_button)
        
        nav_drawer.add_widget(drawer_layout)
        return nav_drawer
        
    def load_applications(self):
        """Load and display applications"""
        try:
            self.app_grid.clear_widgets()
            
            if len(self.access) > 0:
                self.all_tiles.clear()
                self.access['Expired'] = self.access.apply(lambda row: expire_sort(row), axis=1)
                self.access = self.access.sort_values(by=['Expired', 'Solution_Name'], ascending=[True, True])
                self.access.reset_index(inplace=True, drop=True)
                
                # Create application tiles
                for i, row in self.access.iterrows():
                    tile = ApplicationTile(
                        app_name=row['Solution_Name'],
                        app_description=row['Description'],
                        shared_drive_path=row['ApplicationExePath'],
                        environment=row['Status'],
                        release_date=row['Release_Date'],
                        validity_period=row['Validity_Period'],
                        version_number=float(row['Version_Number']) if row['Version_Number'] else 1.0,
                        registration_id=row['UMAT_IAHub_ID']
                    )
                    self.all_tiles.append(tile)
                    self.app_grid.add_widget(tile)
                    
        except Exception as e:
            self.show_error_dialog(f"Failed to load applications: {str(e)}")
            
    def show_no_access(self):
        """Show no access widget"""
        self.app_grid.clear_widgets()
        no_access_widget = NoAccessWidget(self.is_gfbm_user)
        self.app_grid.add_widget(no_access_widget)
        
    def filter_applications(self, instance, text):
        """Filter applications based on search text"""
        self.app_grid.clear_widgets()
        
        if not text:
            # Show all tiles
            for tile in self.all_tiles:
                self.app_grid.add_widget(tile)
        else:
            # Show filtered tiles
            for tile in self.all_tiles:
                if text.lower() in tile.app_name.lower():
                    self.app_grid.add_widget(tile)
                    
    def refresh_applications(self, *args):
        """Refresh applications list"""
        self.search_field.text = ""
        # Implement refresh logic here
        # This would typically reload data from SharePoint
        pass
        
    def show_access_control(self, *args):
        """Show access control dialog"""
        if not self.access_control_dialog:
            self.access_control_dialog = AccessControlDialog(self.username, self.get_managed_lob())
        self.access_control_dialog.open()
        
    def exit_app(self, *args):
        """Exit the application"""
        from kivy.app import App
        App.get_running_app().stop()
        
    def get_user_details(self):
        """Get user details for display"""
        try:
            if self.userdata.empty:
                # Use default details or fetch from API
                details = DETAILS
            else:
                details = [
                    (self.userdata['sid'].values[0], 'icons8-id-50.png'),
                    (self.userdata['display_name'].values[0], 'icons8-user-64.png'),
                    (self.userdata['email'].values[0], 'icons8-email-50.png'),
                    (self.userdata['job_title'].values[0], 'icons8-new-job-50.png'),
                    (self.userdata['building_name'].values[0], 'icons8-location-50.png')
                ]
        except:
            details = DETAILS
        return details
        
    def is_gfbm_user_check(self):
        """Check if user is GFBM user"""
        try:
            self.cost_center_df['cost_center_code'] = self.cost_center_df['cost_center_code'].astype(str)
            cc_column = self.cost_center_df['cost_center_code'].to_list()
            cost_center = getattr(self, 'cost_center', '')
            return cost_center in cc_column
        except:
            return True
            
    def is_administrator(self):
        """Check if user is administrator"""
        # Implement admin check logic
        return False  # Placeholder
        
    def get_managed_lob(self):
        """Get managed lines of business for admin"""
        return LOB  # Placeholder
        
    def show_error_dialog(self, message):
        """Show error dialog"""
        dialog = MDDialog(
            title="Error",
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()