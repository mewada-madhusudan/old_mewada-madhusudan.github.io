"""
Access Control Dialog for PSLV Application
================================================================================
Converted from access.py - Access management interface for Kivy/KivyMD
"""

import re
import threading
from datetime import datetime
import pandas as pd
import urllib3
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.textfield import MDTextField
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.list import MDList, OneLineListItem, TwoLineListItem
from kivymd.uix.card import MDCard
from kivymd.uix.tab import MDTabs, MDTabsBase
from kivymd.uix.progressbar import MDProgressBar
from kivy.metrics import dp
from kivy.clock import Clock
from requests_ntlm import HttpNtlmAuth
from shareplum import Site
from static_config import *

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class FormValidator:
    """Form validation utilities"""
    
    @staticmethod
    def validate_text(text):
        """Validate text field is not empty and contains valid characters"""
        return bool(text and text.strip())
    
    @staticmethod
    def validate_app_path(text):
        """Validate text field is not empty and contains an exe path"""
        return True if text.endswith('.exe') else False
    
    @staticmethod
    def validate_date(date_str):
        """Validate date in YYYY-MM-DD format"""
        try:
            if not date_str:
                return True
            datetime.strptime(date_str, '%Y-%m-%d')
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_version(version):
        """Validate version is a valid float"""
        try:
            if not version:
                return True
            float(version)
            return True
        except ValueError:
            return False

class ValidatingTextField(MDTextField):
    """Text field with validation"""
    
    def __init__(self, validation_type, required=False, **kwargs):
        super().__init__(**kwargs)
        self.validation_type = validation_type
        self.required = required
        self.valid = True
        self.bind(text=self.on_text_changed)
    
    def validate(self):
        """Validate the field content"""
        text = self.text.strip()
        
        # Check if field is required and empty
        if self.required and not text:
            self.set_invalid()
            return False
        
        # If field is optional and empty, it's valid
        if not self.required and not text:
            self.set_valid()
            return True
        
        # Validate based on type
        if self.validation_type == 'text':
            valid = FormValidator.validate_text(text)
        elif self.validation_type == 'date':
            valid = FormValidator.validate_date(text)
        elif self.validation_type == 'version':
            valid = FormValidator.validate_version(text)
        elif self.validation_type == 'app':
            valid = FormValidator.validate_app_path(text)
        else:
            valid = True
        
        if valid:
            self.set_valid()
        else:
            self.set_invalid()
        
        return valid
    
    def set_valid(self):
        """Set field as valid"""
        self.valid = True
        self.error = False
    
    def set_invalid(self):
        """Set field as invalid"""
        self.valid = False
        self.error = True
    
    def on_text_changed(self, instance, text):
        """Reset validation state when user starts typing"""
        if not self.valid:
            self.error = False

class AppTileCard(MDCard):
    """Application tile card for selection"""
    
    def __init__(self, name, description, **kwargs):
        super().__init__(**kwargs)
        self.app_name = name
        self.elevation = 2
        self.radius = [5]
        self.size_hint = (None, None)
        self.size = (dp(300), dp(100))
        self.md_bg_color = 'white'
        
        layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(5),
            padding=dp(10)
        )
        
        # App name
        name_label = MDLabel(
            text=name,
            font_style='Subtitle1',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(30)
        )
        
        # Description
        desc_label = MDLabel(
            text=description,
            font_style='Body2',
            theme_text_color='Secondary',
            text_size=(dp(280), None),
            size_hint_y=None,
            height=dp(50)
        )
        
        layout.add_widget(name_label)
        layout.add_widget(desc_label)
        self.add_widget(layout)

class Tab(MDBoxLayout, MDTabsBase):
    """Tab base class"""
    pass

class AccessControlDialog(MDDialog):
    """Access control management dialog"""
    
    def __init__(self, username, lob, **kwargs):
        super().__init__(**kwargs)
        self.username = username
        self.lob = lob
        self.df = pd.DataFrame()
        self.add_app_fields = {}
        
        self.title = "Access Management"
        self.type = "custom"
        self.size_hint = (0.9, 0.9)
        
        # Refresh data and build UI
        self.refresh_data()
        self.content_cls = self.build_content()
    
    def refresh_data(self):
        """Fetch fresh data from SharePoint"""
        try:
            cred = HttpNtlmAuth(SID, "")
            site = Site(SITE_URL, auth=cred, verify_ssl=False)
            
            sp_list = site.List(SHAREPOINT_LIST)
            sp_data = sp_list.GetListItems(view_name=None)
            df_all = pd.DataFrame(sp_data)
            df_all.fillna('', inplace=True)
            self.df = df_all[df_all['LOB'].isin(self.lob)]
            self.df['Description'] = self.df['Description'].str.slice(0, 50)
            self.df.reset_index(inplace=True, drop=True)
            return True
        except Exception as e:
            print(f"Failed to refresh data: {str(e)}")
            return False
    
    def build_content(self):
        """Build the dialog content"""
        main_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            size_hint=(1, 1)
        )
        
        # Create tabs
        tabs = MDTabs()
        
        # Add Application Tab
        add_app_tab = Tab(title="Add Application")
        add_app_content = self.create_add_app_content()
        add_app_tab.add_widget(add_app_content)
        
        # Manage Access Tab
        manage_access_tab = Tab(title="Manage Access")
        manage_access_content = self.create_manage_access_content()
        manage_access_tab.add_widget(manage_access_content)
        
        tabs.add_widget(add_app_tab)
        tabs.add_widget(manage_access_tab)
        
        main_layout.add_widget(tabs)
        
        return main_layout
    
    def create_add_app_content(self):
        """Create add application tab content"""
        scroll = MDScrollView()
        
        content = MDBoxLayout(
            orientation='vertical',
            spacing=dp(15),
            adaptive_height=True,
            padding=dp(20)
        )
        
        # Title
        title = MDLabel(
            text="Application Details",
            font_style='H6',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(40)
        )
        content.add_widget(title)
        
        # Update mode checkbox
        update_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(40),
            adaptive_height=True
        )
        
        self.update_checkbox = MDCheckbox(
            size_hint=(None, None),
            size=(dp(30), dp(30))
        )
        self.update_checkbox.bind(active=self.toggle_update_mode)
        
        update_label = MDLabel(
            text="Update Existing Application",
            theme_text_color='Primary'
        )
        
        update_layout.add_widget(self.update_checkbox)
        update_layout.add_widget(update_label)
        content.add_widget(update_layout)
        
        # Create form fields
        for field in FIELDS:
            field_widget = self.create_form_field(field)
            content.add_widget(field_widget)
        
        # Buttons
        button_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(50),
            adaptive_height=True
        )
        
        clear_btn = MDFlatButton(
            text="Clear Form",
            on_release=self.clear_form
        )
        
        self.save_btn = MDRaisedButton(
            text="Save",
            md_bg_color='#1976d2',
            on_release=self.save_application
        )
        
        button_layout.add_widget(clear_btn)
        button_layout.add_widget(self.save_btn)
        content.add_widget(button_layout)
        
        scroll.add_widget(content)
        return scroll
    
    def create_form_field(self, field_info):
        """Create a form field widget"""
        field_name, label_text, placeholder, options, field_type, validation_type, required = field_info
        
        field_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(5),
            size_hint_y=None,
            height=dp(80),
            adaptive_height=True
        )
        
        # Label
        label = MDLabel(
            text=label_text + (" *" if required else ""),
            font_style='Caption',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(20)
        )
        
        # Field
        if field_type == "dropdown":
            # For simplicity, using text field for dropdowns in this conversion
            # In a full implementation, you'd use MDSelectionControl or custom dropdown
            field = ValidatingTextField(
                hint_text=f"{placeholder} (Options: {', '.join(options) if options else ''})",
                validation_type=validation_type,
                required=required,
                mode="outlined"
            )
        else:
            field = ValidatingTextField(
                hint_text=placeholder,
                validation_type=validation_type,
                required=required,
                mode="outlined"
            )
        
        self.add_app_fields[field_name] = field
        
        field_layout.add_widget(label)
        field_layout.add_widget(field)
        
        return field_layout
    
    def create_manage_access_content(self):
        """Create manage access tab content"""
        main_layout = MDBoxLayout(
            orientation='horizontal',
            spacing=dp(10)
        )
        
        # Applications list
        apps_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            size_hint_x=0.4
        )
        
        apps_title = MDLabel(
            text="Applications",
            font_style='H6',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(40)
        )
        
        apps_scroll = MDScrollView()
        self.apps_list = MDList()
        
        # Populate apps list
        if hasattr(self, 'df') and not self.df.empty:
            for _, row in self.df.iterrows():
                item = TwoLineListItem(
                    text=row['Solution_Name'],
                    secondary_text=row['Description'][:50] + "..." if len(row['Description']) > 50 else row['Description']
                )
                item.bind(on_release=lambda x, app_name=row['Solution_Name']: self.select_application(app_name))
                self.apps_list.add_widget(item)
        
        apps_scroll.add_widget(self.apps_list)
        apps_layout.add_widget(apps_title)
        apps_layout.add_widget(apps_scroll)
        
        # User management
        users_layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            size_hint_x=0.6
        )
        
        users_title = MDLabel(
            text="Manage Users",
            font_style='H6',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(40)
        )
        
        # User tabs
        user_tabs = MDTabs()
        
        # Existing users tab
        existing_tab = Tab(title="Existing Users")
        existing_content = self.create_existing_users_content()
        existing_tab.add_widget(existing_content)
        
        # Add users tab
        add_users_tab = Tab(title="Add Users")
        add_users_content = self.create_add_users_content()
        add_users_tab.add_widget(add_users_content)
        
        user_tabs.add_widget(existing_tab)
        user_tabs.add_widget(add_users_tab)
        
        users_layout.add_widget(users_title)
        users_layout.add_widget(user_tabs)
        
        main_layout.add_widget(apps_layout)
        main_layout.add_widget(users_layout)
        
        return main_layout
    
    def create_existing_users_content(self):
        """Create existing users management content"""
        layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(10)
        )
        
        label = MDLabel(
            text="Select users to remove access:",
            font_style='Body1',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(30)
        )
        
        scroll = MDScrollView()
        self.existing_users_list = MDList()
        scroll.add_widget(self.existing_users_list)
        
        remove_btn = MDRaisedButton(
            text="Remove Selected Users",
            md_bg_color='#f44336',
            size_hint_y=None,
            height=dp(40),
            on_release=self.remove_selected_users
        )
        
        layout.add_widget(label)
        layout.add_widget(scroll)
        layout.add_widget(remove_btn)
        
        return layout
    
    def create_add_users_content(self):
        """Create add users content"""
        layout = MDBoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(10)
        )
        
        label = MDLabel(
            text="Enter user SIDs (one per line):",
            font_style='Body1',
            theme_text_color='Primary',
            size_hint_y=None,
            height=dp(30)
        )
        
        self.new_users_field = MDTextField(
            hint_text="Paste multiple IDs or enter one per line",
            multiline=True,
            mode="outlined",
            size_hint_y=None,
            height=dp(150)
        )
        
        add_btn = MDRaisedButton(
            text="Add Users",
            md_bg_color='#4caf50',
            size_hint_y=None,
            height=dp(40),
            on_release=self.add_multiple_users
        )
        
        layout.add_widget(label)
        layout.add_widget(self.new_users_field)
        layout.add_widget(add_btn)
        
        return layout
    
    def toggle_update_mode(self, checkbox, value):
        """Toggle between add and update mode"""
        if value:
            self.save_btn.text = "Update"
            # Disable app name field and populate dropdown
        else:
            self.save_btn.text = "Save"
            self.clear_form()
    
    def save_application(self, *args):
        """Save application data"""
        # Validate all fields
        all_valid = True
        for field_name, input_widget in self.add_app_fields.items():
            if isinstance(input_widget, ValidatingTextField):
                if not input_widget.validate():
                    all_valid = False
        
        if not all_valid:
            error_dialog = MDDialog(
                title="Validation Error",
                text="Please check the form for errors",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: error_dialog.dismiss()
                    )
                ]
            )
            error_dialog.open()
            return
        
        # Collect and save data
        new_data = {}
        for field, widget in self.add_app_fields.items():
            new_data[field] = widget.text
        
        try:
            # Add to dataframe and update SharePoint
            self.df = pd.concat([self.df, pd.DataFrame([new_data])], ignore_index=True)
            self.update_sharepoint_db([new_data], 'New')
            
            success_dialog = MDDialog(
                title="Success",
                text="Application has been saved successfully!",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: success_dialog.dismiss()
                    )
                ]
            )
            success_dialog.open()
            
            self.clear_form()
            
        except Exception as e:
            error_dialog = MDDialog(
                title="Error",
                text=f"Failed to save application: {str(e)}",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: error_dialog.dismiss()
                    )
                ]
            )
            error_dialog.open()
    
    def clear_form(self, *args):
        """Clear all form fields"""
        for field_name, input_widget in self.add_app_fields.items():
            input_widget.text = ""
        self.update_checkbox.active = False
    
    def select_application(self, app_name):
        """Select an application for user management"""
        self.selected_app = app_name
        self.load_application_users(app_name)
    
    def load_application_users(self, app_name):
        """Load users for selected application"""
        self.existing_users_list.clear_widgets()
        
        if hasattr(self, 'df') and not self.df.empty:
            app_data = self.df[self.df['Solution_Name'] == app_name]
            if not app_data.empty:
                users = split_user(app_data.iloc[0]['SIDs_For_SolutionAccess'])
                
                for user in users:
                    if user.strip():
                        item = OneLineListItem(text=user.strip())
                        self.existing_users_list.add_widget(item)
    
    def remove_selected_users(self, *args):
        """Remove selected users from application"""
        # Implementation for removing users
        pass
    
    def add_multiple_users(self, *args):
        """Add multiple users to application"""
        # Implementation for adding users
        pass
    
    def update_sharepoint_db(self, dictionary_as_list, operation):
        """Update SharePoint database"""
        try:
            cred = HttpNtlmAuth(SID, "")
            site = Site(SITE_URL, auth=cred, verify_ssl=False)
            sp_list = site.List(SHAREPOINT_LIST)
            sp_list.UpdateListItems(data=dictionary_as_list, kind=operation)
        except Exception as e:
            print(f"Failed to update SharePoint: {str(e)}")
            raise